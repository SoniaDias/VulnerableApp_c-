﻿using System.Collections.Generic;

namespace WebAppMVC.Models
{
    public class User
    {
        public string Name { get; set; }

        public List<string> List { get; set; }
    }
}